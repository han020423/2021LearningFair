import pygame
import winsound

pygame.init()

size = (1800, 600)
screen = pygame.display.set_mode(size)
pygame.display.set_caption("피아노 건반")
clock = pygame.time.Clock()

img = pygame.image.load("img/unnamed.png") #첫 번째 건반 이미지 로드
img = pygame.transform.scale(img, (600,600)) #첫 번째 건반 크기 설정
img1 = pygame.image.load("img/unnamed1.png") #두 번째 건반 이미지 로드
img1 = pygame.transform.scale(img1, (600,600)) #두 번째 건반 크기 설정
img2 = pygame.image.load("img/unnamed2.png") #세 번째 건반 이미지 로드
img2 = pygame.transform.scale(img2, (600,600)) #세 번째 건반 크기 설정
btn = pygame.image.load("img/o.png") #버튼 이미지 로드
btn = pygame.transform.scale(btn, (50, 50)) #버튼 크기 설정

def mp(file):   #소리 출력 함수
   winsound.PlaySound("musicfile/"+file, winsound.SND_ASYNC)

running = True
   
while running:
    clock.tick(30)
    #이미지 위치 설정
    screen.blit(img, (0, 0)) 
    screen.blit(img1, (600, 0))
    screen.blit(img2, (1200, 0))
    
    keys = pygame.key.get_pressed() #눌린 키 감지

    for event in pygame.event.get(): #event가 발생 캐치
       # 1옥타브 도~시
        if keys[pygame.K_z]:
            mp("c4.wav") 
            screen.blit(btn, (15, 500))
        if keys[pygame.K_x]:
            mp("d4.wav")
            screen.blit(btn, (101, 500))
        if keys[pygame.K_c]:
            mp("e4.wav")
            screen.blit(btn, (186, 500))
        if keys[pygame.K_v]:
            mp("f4.wav")
            screen.blit(btn, (272, 500))
        if keys[pygame.K_b]:
            mp("g4.wav")
            screen.blit(btn, (358, 500))
        if keys[pygame.K_n]:
            mp("a4.wav")
            screen.blit(btn, (444, 500))
        if keys[pygame.K_m]:
            mp("b4.wav")
            screen.blit(btn, (530, 500))
        #2옥타브 도~시   
        if keys[pygame.K_COMMA]:
            mp("c5.wav")
            screen.blit(btn, (616, 500))
        if keys[pygame.K_PERIOD]:
            mp("d5.wav")
            screen.blit(btn, (702, 500))
        if keys[pygame.K_SLASH]:
            mp("e5.wav")
            screen.blit(btn, (788, 500))
        if keys[pygame.K_q]:
            mp("f5.wav")
            screen.blit(btn, (874, 500))
        if keys[pygame.K_w]:
            mp("g5.wav")
            screen.blit(btn, (960, 500))
        if keys[pygame.K_e]:
            mp("a5.wav")
            screen.blit(btn, (1046, 500))
        if keys[pygame.K_r]:
            mp("b5.wav")
            screen.blit(btn, (1132, 500))
        #3옥타브 도~시    
        if keys[pygame.K_t]:
            mp("c6.wav")
            screen.blit(btn, (1216, 500))
        if keys[pygame.K_y]:
            mp("d6.wav")
            screen.blit(btn, (1302, 500))
        if keys[pygame.K_u]:
            mp("e6.wav")
            screen.blit(btn, (1388, 500))
        if keys[pygame.K_i]:
            mp("f6.wav")
            screen.blit(btn, (1474, 500))
        if keys[pygame.K_o]:
            mp("g6.wav")
            screen.blit(btn, (1560, 500))
        if keys[pygame.K_p]:
            mp("a6.wav")
            screen.blit(btn, (1646, 500))
        if keys[pygame.K_LEFTBRACKET]:
            mp("b6.wav")
            screen.blit(btn, (1732, 500))
            
        if event.type == pygame.QUIT: # x를 눌러 종료
           running = False
    pygame.display.update() #화면 출력

pygame.quit()
